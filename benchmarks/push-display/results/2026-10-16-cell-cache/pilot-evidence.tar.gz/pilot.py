from pathlib import Path
import subprocess,os,json,time
ROOT=Path.cwd(); OUT=ROOT/'target/display-benchmark/round2'
PRODUCTION=ROOT/'pull-shell/src/main/java/de/mossgrabers/controller/ableton/push/controller/PushFrameEncoder.java'
original=(OUT/'row-original.java').read_text()
encode='''    void encode (final ByteBuffer source)
    {
        if (source.remaining () < WIDTH * HEIGHT * Integer.BYTES)
            throw new IllegalArgumentException ("Incomplete Push bitmap");
        final IntBuffer input = source.duplicate ().order (ByteOrder.LITTLE_ENDIAN).asIntBuffer ();
        input.limit (WIDTH * HEIGHT);
        if (WHOLE_FRAME && this.valid && input.mismatch (this.previousInput) < 0)
        {
            source.rewind ();
            return;
        }
        for (int row = 0; row < HEIGHT; row++)
        {
            input.get (this.rowPixels);
            final int base = row * WIDTH;
            if (this.valid && Arrays.equals (this.rowPixels, 0, WIDTH, this.previousFrame, base, base + WIDTH))
                continue;
            for (int column = 0; column < WIDTH; column += CHUNK)
            {
                final int previous = base + column;
                if (CHUNK != WIDTH && this.valid && Arrays.equals (this.rowPixels, column, column + CHUNK, this.previousFrame, previous, previous + CHUNK))
                    continue;
                System.arraycopy (this.rowPixels, column, this.previousFrame, previous, CHUNK);
                if (CHUNK != WIDTH) System.arraycopy (this.rowPixels, column, this.pixels, 0, CHUNK);
                luminance (this.pixels, this.luminance, this.grayMasks);
                if (Arrays.equals (this.grayMasks, this.allGray))
                    packUncalibrated (this.pixels, this.shaping);
                else
                {
                    channel (this.pixels, this.luminance, this.grayMasks, this.red, 16);
                    channel (this.pixels, this.luminance, this.grayMasks, this.green, 8);
                    channel (this.pixels, this.luminance, this.grayMasks, this.blue, 0);
                    pack (this.red, this.green, this.blue, this.shaping, this.pixels);
                }
                narrow (this.pixels, this.wire, row * STRIDE + column);
            }
        }
        this.valid = true;
        source.rewind ();
    }

'''
def variant(chunk,whole):
 s=original.replace('    private final int [][] previousRows = new int [HEIGHT][WIDTH];\n    private final boolean [] validRows = new boolean [HEIGHT];',f'''    private static final int CHUNK = {chunk};
    private static final boolean WHOLE_FRAME = {str(whole).lower()};
    private final int [] previousFrame = new int [HEIGHT * WIDTH];
    private final IntBuffer previousInput = IntBuffer.wrap (this.previousFrame);
    private boolean valid;
    private final int [] rowPixels = new int [WIDTH];''')
 s=s.replace('private final int [] pixels = new int [WIDTH];','private final int [] pixels = CHUNK == WIDTH ? this.rowPixels : new int [CHUNK];')
 for field in ('allGray','grayMasks','luminance','red','green','blue','shaping'):
  s=s.replace(f'int [] {field} = new int [WIDTH];',f'int [] {field} = new int [CHUNK];')
 s=s.replace('i < WIDTH; i++','i < CHUNK; i++')
 start=s.index('    void encode (');end=s.index('    void copyTo (',start)
 s=s[:start]+encode+s[end:]
 start=s.index('    private static void luminance')
 s=s[:start]+s[start:].replace('x < WIDTH','x < CHUNK')
 return s
jobs=[('row-reference',None,False)] + [(f'chunk-{n}-whole',n,True) for n in [960,64,120,240,480]] + [('chunk-120-no-whole',120,False)]
records=[]
for name,chunk,whole in jobs:
 if chunk:
  source=variant(chunk,whole); PRODUCTION.write_text(source); (OUT/(name+'.java')).write_text(source)
 env=dict(os.environ,PULL_BENCH_FILTER='FrameBenchmark.'+('rowCached$' if chunk is None else 'optimized$'))
 cmd=[str(ROOT/'tools/benchmark-push-display'),'-p','content=capture,random,gray,unchanged,playhead,patch','-f','1','-wi','2','-i','2','-jvmArgsAppend','-Dpull.benchmark.frames='+str(ROOT/'target/display-benchmark/frames'),'-rf','json','-rff',str(OUT/(name+'.json'))]
 print('START',name,flush=True)
 with (OUT/(name+'.log')).open('w') as log: subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 results=json.loads((OUT/(name+'.json')).read_text()); assert len(results)==6
 result={r['params']['content']:round(r['primaryMetric']['score'],3) for r in results}
 records.append(dict(name=name,command=cmd,filter=env['PULL_BENCH_FILTER'],results=result))
 (OUT/'pilots.json').write_text(json.dumps(records,indent=2)+'\n')
 print(name,result,flush=True)
PRODUCTION.write_text(original)
