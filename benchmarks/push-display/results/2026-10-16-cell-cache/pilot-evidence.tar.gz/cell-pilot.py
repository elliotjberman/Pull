from pathlib import Path
import os,json,subprocess
prefix=Path('target/display-benchmark/round2/pilot.py').read_text().split('jobs=')[0]
exec(prefix)

def cell_variant(height):
 s=variant(120*height,True).replace('CHUNK == WIDTH ? this.rowPixels : new int [CHUNK]','new int [CHUNK]')
 s=s.replace('private final int [] rowPixels = new int [WIDTH];','private final int [] framePixels = new int [WIDTH * HEIGHT];')
 start=s.index('        for (int row = 0; row < HEIGHT; row++)');end=s.index('        this.valid = true;',start)
 body='''        input.get (this.framePixels);
        for (int y = 0; y < HEIGHT; y += CELL_HEIGHT)
        {
            for (int x = 0; x < WIDTH; x += 120)
            {
                boolean changed = !this.valid;
                for (int dy = 0; dy < CELL_HEIGHT && !changed; dy++)
                {
                    final int offset = (y + dy) * WIDTH + x;
                    changed = !Arrays.equals (this.framePixels, offset, offset + 120, this.previousFrame, offset, offset + 120);
                }
                if (!changed) continue;
                for (int dy = 0; dy < CELL_HEIGHT; dy++)
                {
                    final int offset = (y + dy) * WIDTH + x;
                    System.arraycopy (this.framePixels, offset, this.previousFrame, offset, 120);
                    System.arraycopy (this.framePixels, offset, this.pixels, dy * 120, 120);
                }
                luminance (this.pixels, this.luminance, this.grayMasks);
                if (Arrays.equals (this.grayMasks, this.allGray)) packUncalibrated (this.pixels, this.shaping);
                else
                {
                    channel (this.pixels, this.luminance, this.grayMasks, this.red, 16);
                    channel (this.pixels, this.luminance, this.grayMasks, this.green, 8);
                    channel (this.pixels, this.luminance, this.grayMasks, this.blue, 0);
                    pack (this.red, this.green, this.blue, this.shaping, this.pixels);
                }
                for (int dy = 0; dy < CELL_HEIGHT; dy++)
                    for (int dx = 0; dx < 120; dx++)
                        this.wire[(y + dy) * STRIDE + x + dx] = (short) this.pixels[dy * 120 + dx];
            }
        }
'''.replace('CELL_HEIGHT',str(height))
 return s[:start]+body+s[end:]

jobs=[('row-macro',None,'macro'),('strip-60',variant(60,True),'capture,random,gray,unchanged,playhead,patch,macro'),('strip-64-macro',variant(64,True),'macro'),('strip-120-macro',variant(120,True),'macro')]+[(f'cell-120x{h}',cell_variant(h),'capture,random,gray,unchanged,playhead,patch,macro') for h in [8,16,160]]
records=[]
for name,source,content in jobs:
 if source: PRODUCTION.write_text(source); (OUT/(name+'.java')).write_text(source)
 env=dict(os.environ,PULL_BENCH_FILTER='FrameBenchmark.'+('optimized$' if source else 'rowCached$'))
 cmd=[str(ROOT/'tools/benchmark-push-display'),'-p','content='+content,'-f','1','-wi','2','-i','2','-jvmArgsAppend','-Dpull.benchmark.frames='+str(ROOT/'target/display-benchmark/frames'),'-rf','json','-rff',str(OUT/(name+'.json'))]
 print('START',name,flush=True)
 with (OUT/(name+'.log')).open('w') as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 results=json.loads((OUT/(name+'.json')).read_text()); assert len(results)==len(content.split(','))
 values={r['params']['content']:round(r['primaryMetric']['score'],3) for r in results}
 records.append(dict(name=name,command=cmd,filter=env['PULL_BENCH_FILTER'],results=values));(OUT/'cell-pilots.json').write_text(json.dumps(records,indent=2)+'\n')
 print(name,values,flush=True)
PRODUCTION.write_text(original)
